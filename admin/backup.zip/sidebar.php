<nav class="sidebar">
    <div class="text-center">
        <img src="admin.jpg" alt="logo" style="width: 80px; height: 80px; border-radius: 50%;">
    </div>
    <h2>Admin Panel</h2>
    <ul class="nav flex-column">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="add_employee.php">Add Employee</a></li>
        <li class="nav-item"><a class="nav-link" href="employeelist.php">Employee List</a></li>
        <li class="nav-item"><a class="nav-link" href="emp_attendence.php">Employee Attendance</a></li>
        <li class="nav-item"><a class="nav-link" href="holidays.php">Holidays List</a></li>
        <li class="nav-item"><a class="nav-link" href="salary_slip.php">Salary Slips</a></li>
        <li class="nav-item"><a class="nav-link" href="payhead.php">Payheads</a></li>
        <li class="nav-item"><a class="nav-link" href="leave_management.php">Leave Management</a></li>
    </ul>
</nav>