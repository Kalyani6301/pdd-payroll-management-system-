<?php
// add_salary.php

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "payroll";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch employee details using emp_code
$emp_code = isset($_GET['employee_id']) ? $_GET['employee_id'] : null;
$employee = null;

if ($emp_code) {
    $sql = "SELECT 
                emp_code, CONCAT(first_name, ' ', last_name) AS name, 
                dob, gender, address, city, state, country, email, mobile_number, 
                identity_doc, idetity_no AS identity_no, emp_type, joining_date, 
                blood_group, designation, department, pan_no, bank_name, account_no, 
                ifsc_code, pf_code 
            FROM employees WHERE emp_code = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $emp_code); // Change "i" to "s"
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <h2 class="text-center">Enter Employee Salary Details</h2>

        <?php if ($employee): ?>
        <form id="salaryForm" class="p-4 bg-white shadow rounded">
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label">Employee Code:</label>
                    <input type="text" name="employee_code" class="form-control" value="<?= htmlspecialchars($employee['emp_code']) ?>" readonly>

                    <label class="form-label">Employee Name:</label>
                    <input type="text" name="employee_name" class="form-control" value="<?= htmlspecialchars($employee['name']) ?>" readonly>

                    <label class="form-label">Designation:</label>
                    <input type="text" name="designation" class="form-control" value="<?= htmlspecialchars($employee['designation']) ?>" readonly>

                    <label class="form-label">Gender:</label>
                    <input type="text" name="gender" class="form-control" value="<?= htmlspecialchars($employee['gender']) ?>" readonly>

                    <label class="form-label">Location:</label>
                    <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($employee['city'] . ', ' . $employee['state'] . ', ' . $employee['country']) ?>" readonly>

                    <label class="form-label">Department:</label>
                    <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($employee['department']) ?>" readonly>

                    <label class="form-label">Date of Joining:</label>
                    <input type="text" name="joining_date" class="form-control" value="<?= htmlspecialchars($employee['joining_date']) ?>" readonly>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Bank Name:</label>
                    <input type="text" name="bank_name" class="form-control" value="<?= htmlspecialchars($employee['bank_name']) ?>" readonly>

                    <label class="form-label">Bank Account:</label>
                    <input type="text" name="bank_account" class="form-control" value="<?= htmlspecialchars($employee['account_no']) ?>" readonly>

                    <label class="form-label">IFSC Code:</label>
                    <input type="text" name="ifsc_code" class="form-control" value="<?= htmlspecialchars($employee['ifsc_code']) ?>" readonly>

                    <label class="form-label">PAN:</label>
                    <input type="text" name="pan" class="form-control" value="<?= htmlspecialchars($employee['pan_no']) ?>" readonly>

                    <label class="form-label">PF Account:</label>
                    <input type="text" name="pf_account" class="form-control" value="<?= htmlspecialchars($employee['pf_code']) ?>" readonly>

                    <label class="form-label">Payable Days:</label>
                    <input type="text" name="working_days" class="form-control" required>

                    <label class="form-label">Leaves:</label>
                    <input type="text" name="leaves" class="form-control" required>
                </div>
            </div>

            <h5 class="mt-3">Salary Details</h5>
            <label class="form-label">Travel Expenses:</label>
            <input type="number" name="travel_expenses" class="form-control" required>

            <label class="form-label">Total Deductions:</label>
            <input type="number" name="deductions" class="form-control" required>

            <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </form>
        <?php else: ?>
        <div class="alert alert-danger text-center">
            Employee not found. Please go back and try again.
        </div>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById("salaryForm").addEventListener("submit", function(event) {
            event.preventDefault();

            const formData = new FormData(this);

            fetch("../api/add_salary.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) this.reset();
            })
            .catch(error => {
                alert("An error occurred. Try again.");
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
