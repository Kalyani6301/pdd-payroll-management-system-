<?php
// employeelist.php

// Database connection (update credentials as per your setup)
$host = "localhost";
$username = "root";
$password = "";
$database = "payroll";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch employee data
$sql = "SELECT 
            emp_code, 
            CONCAT(first_name, ' ', last_name) AS name, 
            idetity_no AS identity, 
            mobile_number AS contact, 
            dob, 
            joining_date AS joining, 
            blood_group AS bloodgroup, 
            emp_type AS employee_type,
            email 
        FROM employees";

$result = $conn->query($sql);

$employees = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Green button for Salary */
        .salary-btn {
            background-color:rgb(241, 60, 14);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 5px; /* Space between buttons */
        }
        .salary-btn:hover {
            background-color:rgb(255, 72, 21);
        }

        /* Blue button for Payhead */
        .payhead-btn {
            background-color:rgb(234, 220, 26);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .payhead-btn:hover {
            background-color:rgb(244, 240, 9);
        }
    </style>
</head>
<body class="bg-light">

    <div class="container mt-5">
        <h2 class="text-center">Employee List</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped mt-3">
                <thead class="table-dark">
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Identity</th>
                        <th>Contact</th>
                        <th>DOB</th>
                        <th>Joining Date</th>
                        <th>Blood Group</th>
                        <th>Employee Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="employeeTableBody">
                    <?php if (!empty($employees)): ?>
                        <?php foreach ($employees as $employee): ?>
                            <tr>
                                <td><?= htmlspecialchars($employee['emp_code']) ?></td>
                                <td><?= htmlspecialchars($employee['name']) ?></td>
                                <td><?= htmlspecialchars($employee['email']) ?></td>
                                <td><?= htmlspecialchars($employee['identity']) ?></td>
                                <td><?= htmlspecialchars($employee['contact']) ?></td>
                                <td><?= htmlspecialchars($employee['dob']) ?></td>
                                <td><?= htmlspecialchars($employee['joining']) ?></td>
                                <td><?= htmlspecialchars($employee['bloodgroup']) ?></td>
                                <td><?= htmlspecialchars($employee['employee_type']) ?></td>
                                <td>
                                <button class="salary-btn" onclick="redirectToSalary('<?= addslashes($employee['emp_code']) ?>')">Salary</button>
                                <button class="payhead-btn" onclick="redirectToPayhead('<?= addslashes($employee['emp_code']) ?>')">Payhead</button>
                        </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center">No employees found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Redirect to add_salary.php with employee_id
        function redirectToSalary(employeeId) {
            window.location.href = `add_salary.php?employee_id=${employeeId}`;
        }

        // Redirect to payhead.php with employee_id
        function redirectToPayhead(employeeId) {
            window.location.href = `pay_structure.php?employee_id=${employeeId}`;
        }
    </script>

</body>
</html>
