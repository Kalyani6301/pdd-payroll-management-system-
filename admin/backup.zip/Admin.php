<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Sidebar */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: rgb(6, 167, 236);
            color: white;
            padding-top: 20px;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 20px;
            margin-bottom: 20px;
        }

        .sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            display: block;
            font-size: 16px;
        }

        .sidebar .nav-link:hover {
            background: rgb(12, 186, 255);
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 0px;
            background: rgba(248, 249, 250, 0.97);
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background: white;
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
     <!-- Sidebar -->
<nav class="sidebar">
    <div class="text-center">
        <img src="admin.jpg" alt="logo" style="width: 80px; height: 80px; border-radius: 50%;">
    </div>
    <h2>Admin Panel</h2>
    <ul class="nav flex-column">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="add_employee.php">Add Employee</a></li>
        <li class="nav-item"><a class="nav-link" href="employeelist.php">Employee List</a></li>
        <li class="nav-item"><a class="nav-link" href="emp_attendence.php">Employee Attendance</a></li>
        <li class="nav-item"><a class="nav-link" href="holidays.php">Holidays List</a></li>
        <li class="nav-item"><a class="nav-link" href="salary_slip.php">Salary Slips</a></li>
        <li class="nav-item"><a class="nav-link" href="payhead.php">Payheads</a></li>
        <li class="nav-item"><a class="nav-link" href="leave_management.php">Leave Management</a></li>
    </ul>
</nav>


        <!-- Main Content -->
        <div class="main-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light" style="background:#06a7ec;">
                <div class="container-fluid">
                    <a class="navbar-brand text-white" href="#">Payroll Management System</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-white" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  Admin
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminDropdown">
                                    <li><a class="dropdown-item" href="admin_profile.php">Profile</a></li>
                                    <li><a class="dropdown-item" href="../admin/admin_logout.php">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <!-- Dashboard Content -->
            <div class="container mt-4">
                <h2 class="mb-4">Welcome to the Admin Dashboard</h2>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
